package calcualdora;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

class CerebroCalculadoraEDTest {

	
	static CerebroCalculadoraED  CerebroTest ;
	private static Operaciones operacionTest;
    public static CalculadoraED CalculadoraTest;	
	String opTest;
	private final static int TAMANOHISTORIAL = 5;
	private static String[] historial;


	
	
	@BeforeAll
	public static void er() {
	historial = new String[TAMANOHISTORIAL];
	CalculadoraTest = new CalculadoraED();	
	CerebroTest = new CerebroCalculadoraED();
	}
	
	
	

@BeforeEach
public void variablesTestSuma(){
CerebroTest.numero1=1;
CerebroTest.numero2=2;
CerebroTest.resultado=CerebroTest.numero1+CerebroTest.numero2;
}
	
	
@Test
public void operarSumaTest() {
//Test para comprobar el método suma

assertEquals(3,CerebroTest.resultado,0);
	
}
@BeforeEach

public void variablesTestResta(){
CerebroTest.numero1=7;
CerebroTest.numero2=4;
CerebroTest.resultado=CerebroTest.numero1-CerebroTest.numero2;

}	
	 
@Test
public void operarRestaTest() {
//Test para comprobar el método resta

assertEquals(3,CerebroTest.resultado,0);
}
	
@BeforeEach
public void variablesTestMultiplica(){
CerebroTest.numero1=7;
CerebroTest.numero2=4;
CerebroTest.resultado=CerebroTest.numero1*CerebroTest.numero2;

}
@Test
public void operarMultiplicaTest() {
//Test para comprobar el método multiplicación

assertEquals(28,CerebroTest.resultado,0);
}
	
@BeforeEach
public void variablesTestDivide(){
CerebroTest.numero1=8;
CerebroTest.numero2=4;
CerebroTest.resultado=CerebroTest.numero1/CerebroTest.numero2;

}
@Test
public void operarDivideTest() {
//Test para comprobar el método división


assertEquals(2,CerebroTest.resultado,1);
}
@BeforeEach
public void variablesTestSumaRes(){
CerebroTest.numero2=0;
CerebroTest.resultado=3;
CerebroTest.resultado=CerebroTest.resultado+CerebroTest.numero2;
}
@Test
public void operarSumaResTest() {
//Test para comprobar el método suma con un resultado anterior

assertEquals(3,CerebroTest.resultado,0);
}	

@BeforeEach
public void variablesTestRestaRes(){
CerebroTest.numero2=4;
CerebroTest.resultado=9;
CerebroTest.resultado=CerebroTest.resultado-CerebroTest.numero2;

}
@Test
public void operarRestaResTest() {
//Test para comprobar el método resta con un resultado anterior
assertEquals(5,CerebroTest.resultado,0);
}	


@BeforeEach
public void variablesTestMultiplicaRes(){
CerebroTest.numero2=7;
CerebroTest.resultado=9;
CerebroTest.resultado=CerebroTest.resultado*CerebroTest.numero2;

}
@Test
public void operarMultiplicaResTest() {

//Test para comprobar el método multiplicación con un resultado anterior

assertNotEquals(63,CerebroTest.resultado,0);
}	


@BeforeEach
public void variablesTestDivideRes(){
CerebroTest.numero2=5;
CerebroTest.resultado=50;
CerebroTest.resultado=CerebroTest.resultado/CerebroTest.numero2;

}
@Test
//Test para comprobar el método división con un resultado anterior

public void operarDivideResTest() {


assertNotEquals(55,CerebroTest.resultado,0);
}	

@AfterEach
public void cambioresul() {

CerebroTest.resultado=13;

}
@Test
public void mostrarResultadoActualTest() {
//Test para comprobar el método mostrar resultado actual

CerebroTest.resultado=13;
assertEquals(13, CerebroTest.resultado,0);

}

@Test
public void numeroaleatorioTest() {
//Test para comprobar el método random
double randomTest=(Math.random()*100+1);
do {
CerebroTest.resultado=(double)(Math.random()*100+1);
} while(CerebroTest.resultado!=randomTest);
	
assertEquals(randomTest,CerebroTest.resultado,0);
}

@Test
public void historialTest() {
//Test para comprobar el historial
CerebroTest.historial[0]=operacionTest.SUMAR.getNombre();
CerebroTest.historial[1]=operacionTest.RESTAR.getNombre();
CerebroTest.historial[2]=operacionTest.RANDOM.getNombre();
CerebroTest.historial[3]=operacionTest.DIVIDIR.getNombre();
CerebroTest.historial[4]=operacionTest.RESULTADO.getNombre();

assertEquals("Suma", CerebroTest.historial[0]);
assertEquals("Resta", CerebroTest.historial[1]);
assertEquals("Número aleatorio", CerebroTest.historial[2]);
assertEquals("División", CerebroTest.historial[3]);
assertEquals("Mostrar resultado", CerebroTest.historial[4]);

}



}
