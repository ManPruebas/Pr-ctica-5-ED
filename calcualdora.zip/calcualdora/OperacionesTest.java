package calcualdora;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class OperacionesTest {

	
String nombreOperacionTest, simboloOperacionTest,infoOperacionTest;
int idOperacionTest;

@BeforeEach
void variablesuma () {
nombreOperacionTest="Suma";	
simboloOperacionTest="+";
infoOperacionTest="Suma dos números";
idOperacionTest	=1;

}
@Test
void testsuma () {
//Test para comprobar todos los atributos de sumar
assertEquals(nombreOperacionTest,Operaciones.SUMAR.getNombre());
assertEquals(simboloOperacionTest,Operaciones.SUMAR.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.SUMAR.getInfo());
assertEquals(idOperacionTest,Operaciones.SUMAR.getId());
}
	
@BeforeEach
void variableresta () {
nombreOperacionTest="Resta";	
simboloOperacionTest="-";
infoOperacionTest="Resta dos números";
idOperacionTest	=2;
	
}
@Test
void testresta () {
//Test para comprobar todos los atributos de restar 
assertEquals(nombreOperacionTest,Operaciones.RESTAR.getNombre());
assertEquals(simboloOperacionTest,Operaciones.RESTAR.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.RESTAR.getInfo());
assertEquals(idOperacionTest,Operaciones.RESTAR.getId());
}
	
@BeforeEach
void variablemultiplicar () {
nombreOperacionTest="Multiplicación";	
simboloOperacionTest="*";
infoOperacionTest="Multiplica dos números";
idOperacionTest	=3;
	
}
@Test
void testmultiplicar () {
//Test para comprobar todos los atributos de multiplicar
assertEquals(nombreOperacionTest,Operaciones.MULTIPLICAR.getNombre());
assertEquals(simboloOperacionTest,Operaciones.MULTIPLICAR.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.MULTIPLICAR.getInfo());
assertEquals(idOperacionTest,Operaciones.MULTIPLICAR.getId());
}

@BeforeEach
void variabledividir () {
nombreOperacionTest="División";	
simboloOperacionTest="/";
infoOperacionTest="Divide dos números";
idOperacionTest	=4;
	
}
@Test
void testdividir () {
//Test para comprobar todos los atributos de dividir 
assertEquals(nombreOperacionTest,Operaciones.DIVIDIR.getNombre());
assertEquals(simboloOperacionTest,Operaciones.DIVIDIR.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.DIVIDIR.getInfo());
assertEquals(idOperacionTest,Operaciones.DIVIDIR.getId());
}
	

@BeforeEach
void variablesuma_res () {
nombreOperacionTest="Sumar al resultado";	
simboloOperacionTest="+=";
infoOperacionTest="Suma un número al resultado actual";
idOperacionTest	=5;
	
}
@Test
void testsuma_res () {
//Test para comprobar todos los atributos de sumar con el resultado
assertEquals(nombreOperacionTest,Operaciones.SUMAR_RES.getNombre());
assertEquals(simboloOperacionTest,Operaciones.SUMAR_RES.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.SUMAR_RES.getInfo());
assertEquals(idOperacionTest,Operaciones.SUMAR_RES.getId());
}
	
@BeforeEach
void variableresta_res () {
nombreOperacionTest="Restar al resultado";	
simboloOperacionTest="-=";
infoOperacionTest="Al resultado actual le resta un número";
idOperacionTest	=6;
	
}
@Test
void testresta_res () {
//Test para comprobar todos los atributos de restar con el resultado
assertEquals(nombreOperacionTest,Operaciones.RESTAR_RES.getNombre());
assertEquals(simboloOperacionTest,Operaciones.RESTAR_RES.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.RESTAR_RES.getInfo());
assertEquals(idOperacionTest,Operaciones.RESTAR_RES.getId());
}
	
@BeforeEach
void variablemultiplicar_res () {

nombreOperacionTest="Multiplicar al resultado";	
simboloOperacionTest="*=";
infoOperacionTest="Multiplica un número al resultado actual";
idOperacionTest	=7;
	
}
@Test
void testmultiplicar_res () {
//Test para comprobar todos los atributos de multiplicar con el resultado
assertEquals(nombreOperacionTest,Operaciones.MULTIPLICAR_RES.getNombre());	
assertEquals(simboloOperacionTest,Operaciones.MULTIPLICAR_RES.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.MULTIPLICAR_RES.getInfo());
assertEquals(idOperacionTest,Operaciones.MULTIPLICAR_RES.getId());
	
	
}	
@BeforeEach
void variabledividir_res () {
nombreOperacionTest="Dividir al resultado";	
simboloOperacionTest="/=";
infoOperacionTest="Resultado actual dividido por un número";
idOperacionTest	=8;
	
}
@Test
void testdividir_res () {
//Test para comprobar todos los atributos de dividir con el resultado
assertEquals(nombreOperacionTest,Operaciones.DIVIDIR_RES.getNombre());	
assertEquals(simboloOperacionTest,Operaciones.DIVIDIR_RES.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.DIVIDIR_RES.getInfo());
assertEquals(idOperacionTest,Operaciones.DIVIDIR_RES.getId());
	
	
}
@BeforeEach
void variableresul () {
nombreOperacionTest="Mostrar resultado";	
simboloOperacionTest="!";
infoOperacionTest="Muestra el último resultado";
idOperacionTest	=9;
	
}
@Test
void testresul () {	
//Test para comprobar todos los atributos del resultado
assertEquals(nombreOperacionTest,Operaciones.RESULTADO.getNombre());
assertEquals(simboloOperacionTest,Operaciones.RESULTADO.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.RESULTADO.getInfo());
assertEquals(idOperacionTest,Operaciones.RESULTADO.getId());
	
}

@BeforeEach
void variablerandom () {

nombreOperacionTest="Número aleatorio";	
simboloOperacionTest="¿?";
infoOperacionTest="Crea un número aleatorio 1-100";
idOperacionTest	=10;
	
}
@Test
void testrandom () {	
//Test para comprobar todos los atributos de random
assertEquals(nombreOperacionTest,Operaciones.RANDOM.getNombre());
assertEquals(simboloOperacionTest,Operaciones.RANDOM.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.RANDOM.getInfo());
assertEquals(idOperacionTest,Operaciones.RANDOM.getId());
		

}
@BeforeEach
void variablehistorial () {

nombreOperacionTest="Historial";	
simboloOperacionTest="h";
infoOperacionTest="Muestra las cinco últimas operaciones";
idOperacionTest	=11;
	
}
@Test
void testhistorial () {		
//Test para comprobar todos los atributos del historial
assertEquals(nombreOperacionTest,Operaciones.HISTORIAL.getNombre());
assertEquals(simboloOperacionTest,Operaciones.HISTORIAL.getSimbolo());
assertEquals(infoOperacionTest,Operaciones.HISTORIAL.getInfo());
assertEquals(idOperacionTest,Operaciones.HISTORIAL.getId());
	
	
}

@Test
void testget() {
//Test para comprobarel funcionamiento de los gets
nombreOperacionTest="Suma";	
simboloOperacionTest="+";
infoOperacionTest="Suma dos números";
idOperacionTest	=1;	
String opciónMenu=idOperacionTest+nombreOperacionTest;

assertEquals(nombreOperacionTest,Operaciones.SUMAR.getNombre());
assertEquals(infoOperacionTest,Operaciones.SUMAR.getInfo());
assertEquals(simboloOperacionTest,Operaciones.SUMAR.getSimbolo());
assertEquals(idOperacionTest,Operaciones.SUMAR.getId());
assertEquals(opciónMenu,Operaciones.SUMAR.getId()+Operaciones.SUMAR.getNombre());


}

















}
