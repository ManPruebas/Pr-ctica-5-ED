## Requisitos de la calculadora ED

1. La calculadora debe ofrecer una interfaz de consola para decidir las operaciones e introducir los números y operaciones.

2. La calculadora mostrará el resultado de las operaciones por consola.

3. El resultado de las operaciones se mostrará junto a los parámetros de la operación y el símbolo de la operación.

4. La calculadora podrá realizar sumas de dos números.

5. La calculadora podrá realizar restas de dos números.

6. La calculadora podrá realizar multiplicaciones de dos números.

7. La calculadora podrá realizar divisiones de dos números.

8. La calculadora podrá sumar un número al último resultado.

9. La calculadora podrá restar un número al último resultado.

10. La calculadora podrá multiplicar un número al último resultado.

11. La calculadora podrá dividir el último resultado por un número.

12. La calculadora podrá visualizar cual ha sido el último resultado.

13. La calculadora podrá visualizar las últimas cinco operaciones realizadas.

14. La calculadora podrá generar números aleatorios de 0 a 100.

15. Los números manejados por la calculadora como parámetros y resultado serán de 32 bits en coma flotante IEEE 754.